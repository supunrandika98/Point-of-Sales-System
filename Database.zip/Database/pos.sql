-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3308
-- Generation Time: May 18, 2022 at 12:43 PM
-- Server version: 8.0.18
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pos`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
CREATE TABLE IF NOT EXISTS `customers` (
  `Customer_ID` int(11) NOT NULL,
  `Name` varchar(256) NOT NULL,
  `PhoneNumber` int(10) NOT NULL,
  `Address` varchar(256) NOT NULL,
  PRIMARY KEY (`Customer_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`Customer_ID`, `Name`, `PhoneNumber`, `Address`) VALUES
(1, 'Kavindu Sankalpa', 711234567, 'Gampaha'),
(2, 'Chanuka Prakash', 779874561, 'Pannipitiya');

-- --------------------------------------------------------

--
-- Table structure for table `grn`
--

DROP TABLE IF EXISTS `grn`;
CREATE TABLE IF NOT EXISTS `grn` (
  `GRN_ID` int(11) NOT NULL AUTO_INCREMENT,
  `ItemName` varchar(256) NOT NULL,
  `ItemDescription` varchar(256) DEFAULT NULL,
  `Quantity` int(11) NOT NULL,
  `SupplierName` varchar(256) NOT NULL,
  `Company` varchar(256) NOT NULL,
  `Price` int(11) NOT NULL,
  PRIMARY KEY (`GRN_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `grn`
--

INSERT INTO `grn` (`GRN_ID`, `ItemName`, `ItemDescription`, `Quantity`, `SupplierName`, `Company`, `Price`) VALUES
(1, 'Biscuits', 'Manchee Chocolate Biscuits', 120, 'Thiraj Adhikari', 'CBL', 70),
(2, 'Signal Toothpaste', '150g new packs', 80, 'Rajith Malaka', 'UNILIVER', 100),
(3, 'Milk Powder', '400g packs', 60, 'Pasindu Deshan', 'Highland', 700);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `Product_ID` int(11) NOT NULL AUTO_INCREMENT,
  `ProductName` varchar(256) NOT NULL,
  `Description` varchar(256) DEFAULT NULL,
  `Price` int(11) NOT NULL,
  `Brand` varchar(256) NOT NULL,
  `Status` varchar(256) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Barcode` varchar(256) NOT NULL,
  PRIMARY KEY (`Product_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`Product_ID`, `ProductName`, `Description`, `Price`, `Brand`, `Status`, `Quantity`, `Barcode`) VALUES
(1, 'Biscuits', 'Manchee Chocalate Biscuits', 85, 'CBL', 'Available', 115, '0001'),
(2, 'Signal Toothpaste', '150g packs', 135, 'UNILIVER', 'Available', 79, '0002'),
(3, 'Milk Powder', '400g packs', 765, 'Highland', 'Available', 58, '0003');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
CREATE TABLE IF NOT EXISTS `sales` (
  `Sales_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Date` varchar(256) NOT NULL,
  `Cashier` varchar(256) NOT NULL,
  `Subtotal` int(11) NOT NULL,
  `Pay` int(11) NOT NULL,
  `Balance` int(11) NOT NULL,
  PRIMARY KEY (`Sales_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`Sales_ID`, `Date`, `Cashier`, `Subtotal`, `Pay`, `Balance`) VALUES
(1, '2022/03/24', '', 170, 200, 30),
(2, '2022/03/24', '', 1665, 1700, 35),
(3, '2022/05/18', '', 85, 100, 15),
(4, '2022/05/18', 'naz', 85, 100, 15),
(5, '2022/05/18', 'supun', 85, 100, 15);

-- --------------------------------------------------------

--
-- Table structure for table `sales_product`
--

DROP TABLE IF EXISTS `sales_product`;
CREATE TABLE IF NOT EXISTS `sales_product` (
  `SalesProduct_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Sales_ID` int(11) NOT NULL,
  `ProductBarcode` varchar(256) NOT NULL,
  `Sell_price` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Total` int(11) NOT NULL,
  PRIMARY KEY (`SalesProduct_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `sales_product`
--

INSERT INTO `sales_product` (`SalesProduct_ID`, `Sales_ID`, `ProductBarcode`, `Sell_price`, `Quantity`, `Total`) VALUES
(1, 1, '0001', 85, 2, 170),
(2, 2, '0003', 765, 2, 1530),
(3, 2, '0002', 135, 1, 135),
(4, 3, '0001', 85, 1, 85),
(5, 4, '0001', 85, 1, 85),
(6, 5, '0001', 85, 1, 85);

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
CREATE TABLE IF NOT EXISTS `suppliers` (
  `Supplier_ID` int(11) NOT NULL,
  `Name` varchar(256) NOT NULL,
  `PhoneNumber` int(10) NOT NULL,
  `Address` varchar(256) NOT NULL,
  `Company` varchar(256) NOT NULL,
  `Status` varchar(256) NOT NULL,
  PRIMARY KEY (`Supplier_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`Supplier_ID`, `Name`, `PhoneNumber`, `Address`, `Company`, `Status`) VALUES
(1, 'Thiraj Adhikari', 784786880, 'Homagama', 'CBL', 'Available'),
(2, 'Rajith Malaka', 712942330, 'Colombo', 'UNILIVER', 'Available'),
(3, 'Pasindu Deshan', 114972215, 'Padukka', 'Highland', 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `User_ID` int(11) NOT NULL,
  `FullName` varchar(256) NOT NULL,
  `UserName` varchar(256) NOT NULL,
  `Password` varchar(256) NOT NULL,
  `NIC` varchar(10) NOT NULL,
  `PhoneNumber` int(10) NOT NULL,
  `Age` int(2) NOT NULL,
  `Status` varchar(256) NOT NULL,
  PRIMARY KEY (`User_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`User_ID`, `FullName`, `UserName`, `Password`, `NIC`, `PhoneNumber`, `Age`, `Status`) VALUES
(1, 'Supun Randika', 'supun', '123', '980731456V', 714125915, 24, 'Admin'),
(2, 'Gnei Nazreen', 'naz', '123', '123456789V', 112729729, 24, 'Cashier');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
